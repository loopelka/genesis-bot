"""
services/products_service.py — Читает товары из локального products.xlsx (openpyxl).

Полностью заменяет sheets.py. Публичный интерфейс идентичен:
    products_service.get_all_products()
    products_service.get_products_by_category(category)
    products_service.get_product_by_id(product_id)
    products_service.get_available_categories()
    products_service.invalidate_cache()
    products_service.last_error

Структура таблицы (строка 1 — заголовки, данные со строки 2):
    A: ID | B: Категория | C: Название | D: Дозировка | E: Цена | F: Остаток | G: Фото

Тяжёлое чтение файла выполняется через run_in_executor,
чтобы не блокировать asyncio event loop.
"""
import asyncio
import logging
import os
from pathlib import Path
from typing import List, Optional

import openpyxl
from cachetools import TTLCache

from config.settings import settings
from services.models import Product

logger = logging.getLogger(__name__)

# Путь до файла относительно корня проекта
XLSX_PATH = Path(settings.products_file)


class ProductsService:
    """
    Читает и кэширует товары из products.xlsx.
    Кэш сбрасывается через CACHE_TTL секунд (по умолчанию 300).
    """

    def __init__(self) -> None:
        self._cache: TTLCache = TTLCache(maxsize=1, ttl=settings.cache_ttl)
        self._lock = asyncio.Lock()
        self._last_error: Optional[str] = None

    # ── Приватные методы ──────────────────────────────────────────────────────

    def _read_xlsx(self) -> List[List]:
        """
        Читает все строки данных из xlsx (блокирующий вызов).
        Возвращает список строк, каждая строка — список значений ячеек A–G.
        Строка 1 (заголовки) пропускается.
        """
        if not XLSX_PATH.exists():
            raise FileNotFoundError(
                f"Файл не найден: {XLSX_PATH.resolve()}\n"
                f"Создайте products.xlsx в корне проекта."
            )

        wb = openpyxl.load_workbook(XLSX_PATH, read_only=True, data_only=True)
        ws = wb.active  # Берём первый (активный) лист

        rows = []
        for i, row in enumerate(ws.iter_rows(min_row=2, values_only=True), start=2):
            # iter_rows возвращает кортеж; конвертируем в список строк
            cells = [str(cell).strip() if cell is not None else "" for cell in row]
            # Пропускаем полностью пустые строки
            if all(c == "" for c in cells):
                continue
            rows.append(cells)
            logger.debug("Прочитана строка %d: %s", i, cells)

        wb.close()
        return rows

    # ── Публичный async API ───────────────────────────────────────────────────

    async def get_all_products(self) -> List[Product]:
        """
        Возвращает все валидные товары, используя кэш при наличии.
        При ошибке чтения возвращает устаревший кэш (если есть) или [].
        """
        async with self._lock:
            if "products" in self._cache:
                return self._cache["products"]

            try:
                loop = asyncio.get_event_loop()
                rows = await loop.run_in_executor(None, self._read_xlsx)

                products: List[Product] = []
                for i, row in enumerate(rows, start=2):
                    product = Product.from_row(row)
                    if product is not None:
                        products.append(product)
                    else:
                        logger.warning("Пропущена некорректная строка %d: %s", i, row)

                self._cache["products"] = products
                self._last_error = None
                logger.info(
                    "Загружено %d товаров из %s", len(products), XLSX_PATH.name
                )
                return products

            except FileNotFoundError as e:
                self._last_error = str(e)
                logger.error(self._last_error)
                return []

            except Exception as e:
                self._last_error = str(e)
                logger.exception("Ошибка чтения %s: %s", XLSX_PATH.name, e)
                # При сбое возвращаем устаревший кэш, если он есть
                return self._cache.get("products", [])

    async def get_products_by_category(self, category: str) -> List[Product]:
        """Возвращает товары выбранной категории (без учёта регистра)."""
        all_products = await self.get_all_products()
        return [p for p in all_products if p.category.lower() == category.lower()]

    async def get_product_by_id(self, product_id: int) -> Optional[Product]:
        """Возвращает товар по ID или None."""
        all_products = await self.get_all_products()
        for product in all_products:
            if product.product_id == product_id:
                return product
        return None

    async def get_available_categories(self) -> List[str]:
        """Возвращает уникальные категории в порядке первого появления."""
        all_products = await self.get_all_products()
        seen: List[str] = []
        for p in all_products:
            if p.category not in seen:
                seen.append(p.category)
        return seen

    def invalidate_cache(self) -> None:
        """Принудительно сбрасывает кэш — следующий запрос перечитает файл."""
        self._cache.clear()
        logger.info("Кэш товаров сброшен")

    @property
    def last_error(self) -> Optional[str]:
        return self._last_error


# Синглтон — используется во всех хендлерах
products_service = ProductsService()
