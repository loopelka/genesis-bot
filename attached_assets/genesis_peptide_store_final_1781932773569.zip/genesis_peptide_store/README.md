# 🧬 Genesis Peptide Store — Telegram Bot

Production-ready Telegram магазин на Python 3.12 + aiogram 3.x + Google Sheets API.

---

## 📁 Структура проекта

```
genesis_peptide_store/
├── main.py                     # Точка входа
├── keep_alive.py               # Flask-сервер для Replit (опционально)
├── get_file_id.py              # Утилита получения Telegram file_id
├── requirements.txt
├── .env.example
├── .env                        # НЕ коммитить в git!
├── .replit                     # Конфиг Replit
├── .gitignore
├── credentials.json            # Google Service Account — НЕ коммитить!
│
├── config/
│   ├── __init__.py
│   ├── settings.py             # Загрузка .env, типизированные настройки
│   └── faq.py                  # Вопросы и ответы FAQ
│
├── services/
│   ├── __init__.py
│   ├── models.py               # Product, OrderForm, категории
│   └── sheets.py               # Google Sheets API + кэш
│
├── keyboards/
│   ├── __init__.py
│   └── builders.py             # Все InlineKeyboardMarkup
│
├── handlers/
│   ├── __init__.py             # Агрегатор роутеров
│   ├── start.py                # /start, главное меню
│   ├── catalog.py              # Каталог, категории, карточка товара
│   ├── order.py                # FSM заказ (3 шага + подтверждение)
│   ├── info.py                 # Доставка, оплата, прайс
│   ├── faq.py                  # FAQ
│   └── manager.py              # Сообщение менеджеру (FSM)
│
└── utils/
    ├── __init__.py
    ├── states.py               # FSM States: OrderStates, ManagerStates
    └── helpers.py              # safe_send_message, safe_edit_message и др.
```

---

## ⚙️ Шаг 1 — Создание Telegram бота

1. Откройте [@BotFather](https://t.me/BotFather) в Telegram
2. Отправьте `/newbot`
3. Введите имя: `Genesis Peptide Store`
4. Введите username: `genesis_peptide_bot` (или любой свободный)
5. Скопируйте **токен** — он выглядит как `7123456789:AAF_abc123...`
6. Вставьте в `.env` → `BOT_TOKEN=`

**Узнать свой Telegram ID:**
1. Откройте [@userinfobot](https://t.me/userinfobot)
2. Отправьте `/start`
3. Скопируйте число из поля `Id:`
4. Вставьте в `.env` → `ADMIN_ID=`

---

## 🔑 Шаг 2 — Подключение Google Sheets API

### 2.1. Создание проекта в Google Cloud

1. Перейдите на [console.cloud.google.com](https://console.cloud.google.com)
2. Нажмите **"Select a project"** → **"New Project"**
3. Имя проекта: `genesis-peptide-bot` → **Create**
4. Убедитесь, что выбран созданный проект

### 2.2. Включение Google Sheets API

1. В боковом меню: **APIs & Services** → **Library**
2. Найдите **"Google Sheets API"** → нажмите → **Enable**

### 2.3. Создание Service Account

1. **APIs & Services** → **Credentials**
2. Нажмите **"+ Create Credentials"** → **"Service account"**
3. Имя: `genesis-sheets-reader` → **Create and Continue**
4. Role: **"Viewer"** → **Continue** → **Done**
5. В списке Service Accounts нажмите на созданный аккаунт
6. Вкладка **"Keys"** → **"Add Key"** → **"Create new key"**
7. Формат: **JSON** → **Create**
8. Файл скачается автоматически. Переименуйте его в `credentials.json`
9. Поместите `credentials.json` в корень проекта

### 2.4. Создание Google Sheets таблицы

1. Создайте новую таблицу на [sheets.google.com](https://sheets.google.com)
2. Назовите лист: `Sheet1` (или укажите своё название в `SHEET_NAME=`)

**Структура первой строки (заголовки — строка 1):**

| A  | B          | C         | D          | E     | F       | G    |
|----|------------|-----------|------------|-------|---------|------|
| ID | Категория  | Название  | Дозировка  | Цена  | Остаток | Фото |

**Пример данных (строка 2 и далее):**

| 1 | Виалки | Retatrutide | 10 mg | 4500 | 10 | RETA10_file_id |
|---|--------|-------------|-------|------|----|----------------|
| 2 | Виалки | BPC-157     | 5 mg  | 2800 | 5  |                |
| 3 | Виалки | TB-500      | 2 mg  | 3200 | 0  | TB500_file_id  |

> ⚠️ Если фото нет — оставьте ячейку G пустой. Карточка отобразится без изображения.

### 2.5. Предоставление доступа к таблице

1. Откройте созданную таблицу
2. Нажмите **"Поделиться"** (Share)
3. В поле email введите email вашего Service Account  
   (он есть в файле `credentials.json` в поле `client_email`)  
   Выглядит как: `genesis-sheets-reader@genesis-peptide-bot.iam.gserviceaccount.com`
4. Выберите роль **"Читатель"** (Viewer)
5. Нажмите **"Отправить"**

### 2.6. Получение ID таблицы

URL таблицы выглядит так:
```
https://docs.google.com/spreadsheets/d/1BxiMVs0XRA5nFMdKvBdBZjgmUUqptlbs74OgVE2upms/edit
```
ID таблицы — это часть между `/d/` и `/edit`:
```
1BxiMVs0XRA5nFMdKvBdBZjgmUUqptlbs74OgVE2upms
```
Вставьте в `.env` → `GOOGLE_SHEETS_ID=`

---

## 🖼️ Шаг 3 — Получение Telegram file_id для фотографий

Telegram хранит фото на своих серверах. Вместо URL используется `file_id`.

### Способ 1 — Утилита get_file_id.py (рекомендуется)

```bash
python get_file_id.py
```

1. Запустите утилиту
2. Откройте вашего бота в Telegram
3. Отправьте боту фото товара
4. Бот ответит с `file_id` — скопируйте его в столбец **G** таблицы
5. Повторите для каждого товара
6. Остановите: `Ctrl+C`

### Способ 2 — Через @getidsbot

1. Перешлите фото боту [@getidsbot](https://t.me/getidsbot)
2. Скопируйте `file_id` из ответа

> ⚠️ `file_id` привязан к конкретному боту. Файлы, отправленные одному боту, нельзя использовать в другом.

---

## 🚀 Шаг 4 — Запуск на Replit

### 4.1. Создание Repl

1. Зайдите на [replit.com](https://replit.com) → **Create Repl**
2. Выберите шаблон **Python**
3. Название: `genesis-peptide-store`

### 4.2. Загрузка файлов

Загрузите все файлы проекта через файловый менеджер Replit:
- Все `.py` файлы
- Все папки (`handlers/`, `services/`, `keyboards/`, `utils/`, `config/`)
- `requirements.txt`
- `credentials.json`

### 4.3. Настройка секретов (Secrets)

В Replit **НЕ создавайте** файл `.env` — используйте встроенные **Secrets**:

1. В боковой панели нажмите 🔒 **Secrets**
2. Добавьте по одному:

| Key                      | Value                              |
|--------------------------|------------------------------------|
| `BOT_TOKEN`              | `7123456789:AAF_abc123...`         |
| `ADMIN_ID`               | `123456789`                        |
| `GOOGLE_SHEETS_ID`       | `1BxiMVs0XRA5nFMdKvBdBZjgmUUqptlbs74OgVE2upms` |
| `GOOGLE_CREDENTIALS_FILE`| `credentials.json`                 |
| `SHEET_NAME`             | `Sheet1`                           |
| `CACHE_TTL`              | `300`                              |

### 4.4. Установка зависимостей

В Shell Replit выполните:
```bash
pip install -r requirements.txt
```

### 4.5. Запуск

Нажмите кнопку **▶ Run** или в Shell:
```bash
python main.py
```

### 4.6. Поддержание работы 24/7 (Replit Free)

Replit останавливает проект при неактивности. Для 24/7:

**Вариант A — Replit Deployments (платно, рекомендуется):**
- В панели нажмите **Deploy** → **Background Worker**
- Бот работает постоянно без дополнительных настроек

**Вариант B — UptimeRobot (бесплатно):**

1. В `main.py` добавьте в самом начале функции `main()`:
```python
from keep_alive import keep_alive
keep_alive()
```
2. Также добавьте `flask` в `requirements.txt`
3. Зарегистрируйтесь на [uptimerobot.com](https://uptimerobot.com)
4. Создайте монитор типа **HTTP(s)**
5. URL: `https://ваш-repl.ваш-username.repl.co`
6. Интервал: 5 минут

---

## ➕ Шаг 5 — Добавление новых товаров

### Через Google Sheets (основной способ)

1. Откройте таблицу Google Sheets
2. Добавьте новую строку в конце:

```
| 101 | Виалки | HGH Fragment 176-191 | 2 mg | 1800 | 15 | HGH_file_id |
```

3. Убедитесь, что ID уникален (не совпадает с существующими)
4. Бот автоматически подхватит изменения через `CACHE_TTL` секунд (по умолчанию 5 мин)

### Немедленное обновление кэша

Если нужно обновить мгновенно, перезапустите бота (кнопка **Stop** → **Run**).

### Добавление новых категорий

В файле `services/models.py` добавьте категорию:
```python
CATEGORY_NEW = "Новая категория"
ALL_CATEGORIES = [CATEGORY_VIALS, CATEGORY_SPRAYS, CATEGORY_SUPPLIES, CATEGORY_CONSULT, CATEGORY_NEW]
CATEGORY_EMOJI = {
    ...
    CATEGORY_NEW: "🆕",
}
```

### Добавление FAQ вопросов

Отредактируйте `config/faq.py`:
```python
FAQEntry(
    question="Ваш новый вопрос?",
    answer="Развёрнутый ответ на вопрос."
),
```

---

## 🔧 Локальный запуск (разработка)

```bash
# Клонируйте/скопируйте проект
cd genesis_peptide_store

# Создайте виртуальное окружение
python3.12 -m venv .venv
source .venv/bin/activate  # Linux/Mac
# .venv\Scripts\activate   # Windows

# Установите зависимости
pip install -r requirements.txt

# Скопируйте и заполните .env
cp .env.example .env
# Отредактируйте .env

# Запустите бота
python main.py
```

---

## 🛡️ Безопасность

| Что защищено          | Как                                              |
|-----------------------|--------------------------------------------------|
| Токен бота            | `.env` / Replit Secrets, не в коде              |
| Admin ID              | `.env` / Replit Secrets                          |
| Google credentials    | `credentials.json` в `.gitignore`               |
| FSM состояния         | MemoryStorage (в памяти, изолировано по user_id) |
| API ошибки            | `try/except` + логирование во всех сервисах     |
| Telegram ошибки       | `safe_send_message` / `safe_edit_message`       |

---

## 📊 Google Sheets — формат данных

| Столбец | Заголовок  | Тип     | Пример              | Обязательный |
|---------|------------|---------|---------------------|--------------|
| A       | ID         | Число   | `1`                 | ✅            |
| B       | Категория  | Текст   | `Виалки`            | ✅            |
| C       | Название   | Текст   | `Retatrutide`       | ✅            |
| D       | Дозировка  | Текст   | `10 mg`             | ✅            |
| E       | Цена       | Число   | `4500`              | ✅            |
| F       | Остаток    | Число   | `10`                | ✅            |
| G       | Фото       | Текст   | `AgACAgI...` (file_id) | ❌ (опционально) |

> ⚠️ **Строка 1** — заголовки. Данные начинаются со **строки 2**.  
> ⚠️ Цену и остаток вводите только цифрами (без пробелов, рублей и пр.).

---

## 🐛 Устранение ошибок

| Ошибка | Причина | Решение |
|--------|---------|---------|
| `BOT_TOKEN is not set` | Не заполнен .env | Добавьте токен в .env или Secrets |
| `ADMIN_ID is not set` | Не заполнен .env | Добавьте ваш Telegram ID |
| `credentials.json not found` | Файл не загружен | Загрузите credentials.json в корень |
| `403 Forbidden` (Sheets) | Нет доступа к таблице | Поделитесь таблицей с email сервисного аккаунта |
| `400 Bad Request` (фото) | Неверный file_id | Пересоздайте file_id через get_file_id.py |
| Бот не отвечает | Процесс упал | Проверьте логи, перезапустите |

---

## 📌 Переменные окружения

| Переменная               | Описание                              | По умолчанию   |
|--------------------------|---------------------------------------|----------------|
| `BOT_TOKEN`              | Токен Telegram бота от @BotFather    | **обязательно**|
| `ADMIN_ID`               | Telegram ID администратора            | **обязательно**|
| `GOOGLE_SHEETS_ID`       | ID Google Sheets таблицы             | **обязательно**|
| `GOOGLE_CREDENTIALS_FILE`| Путь к credentials.json             | `credentials.json` |
| `SHEET_NAME`             | Название листа в таблице             | `Sheet1`       |
| `CACHE_TTL`              | Время кэша в секундах                | `300`          |
